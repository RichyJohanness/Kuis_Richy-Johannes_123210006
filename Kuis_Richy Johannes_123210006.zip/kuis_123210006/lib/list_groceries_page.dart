import 'package:flutter/material.dart';
import 'package:kuis_123210006/detail_groceries_page.dart';
import 'groceries.dart';

class ListGroceriesPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'KUIS TPM IF- E',
          style: TextStyle(color: Colors.white),
        ),
        backgroundColor: Colors.green,
      ),
      body: GridView.builder(
        gridDelegate:
        SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3),
        itemBuilder: (context, index) {
          final Groceries grocery = groceryList[index];
          return InkWell(
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => DetailGroceriesPage(grocery: grocery),
                ),
              );
            },
            child: Card(
              child: Column(
                children: [
                  Container(
                    width: MediaQuery.of(context).size.width * 0.18,
                    height: MediaQuery.of(context).size.height * 0.18,
                    child: Image.network(
                      grocery.productImageUrls[0], // Displaying first image
                      errorBuilder: (context, error, stackTrace) {
                        return Image.asset('assets/images/error_image.png');
                        // Ganti 'assets/images/error_image.png' dengan path gambar lokal yang ingin Anda tampilkan untuk gambar yang gagal dimuat.
                      },
                    ),
                  ),
                  Text(
                    grocery.name,
                    style: TextStyle(fontWeight: FontWeight.bold),
                    textAlign: TextAlign.center,
                  ),
                  SizedBox(height: 8),
                  Text(
                    'Diskon: ${grocery.discount}',
                    style: TextStyle(color: Colors.red),
                    textAlign: TextAlign.left,
                  ),
                  Text(
                    'Harga: ${grocery.price}',
                    textAlign: TextAlign.left,
                  ),
                  Text(
                    'Review: ${grocery.reviewAverage}',
                    textAlign: TextAlign.left,
                  ),
                ],
              ),
            ),
          );
        },
        itemCount: groceryList.length,
      ),
    );
  }
}
