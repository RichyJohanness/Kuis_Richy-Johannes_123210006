import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'groceries.dart';

class DetailGroceriesPage extends StatelessWidget {
  final Groceries grocery;

  DetailGroceriesPage({required this.grocery});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'KUIS TPM IF- E',
          style: TextStyle(color: Colors.white),
        ),
        backgroundColor: Colors.green,
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Image.network(grocery.productImageUrls[0]), // Displaying first image
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    grocery.name,
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 20.0,
                    ),
                  ),
                  SizedBox(height: 8.0),
                  Text(
                    grocery.description,
                    style: TextStyle(fontSize: 16.0),
                  ),
                  SizedBox(height: 8.0),
                  Text(
                    'Price: ${grocery.price}',
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 8.0),
                  Text('Stock: ${grocery.stock}'),
                  SizedBox(height: 8.0),
                  Text('Discount: ${grocery.discount}'),
                  SizedBox(height: 8.0),
                  Text('Store: ${grocery.storeName}'),
                  SizedBox(height: 8.0),
                  ElevatedButton(
                    onPressed: () {
                      _launchURL(grocery.productUrl);
                    },
                    child: Text(
                      'Ke Tokonya aja',
                      style: TextStyle(color: Colors.green),
                      textAlign: TextAlign.right,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Function to open URL
  void _launchURL(String url) async {
    if (await canLaunch(url)) {
      await launch(url);
    } else {
      throw 'Could not launch $url';
    }
  }
}
