import 'package:flutter/material.dart';
import 'list_groceries_page.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'KuisTPM IF -E',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: ListGroceriesPage(), // Halaman utama aplikasi
    );
  }
}
