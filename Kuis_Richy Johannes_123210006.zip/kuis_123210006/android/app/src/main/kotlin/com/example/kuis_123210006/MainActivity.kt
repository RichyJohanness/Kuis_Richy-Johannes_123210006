package com.example.kuis_123210006

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
